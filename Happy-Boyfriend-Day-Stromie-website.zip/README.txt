# Happy Boyfriend Day Stromie 💗

## Easy editing
Open `index.html` and search for:
- `Happy Boyfriend Day` → change the title
- `mainMessage` → change the main Hinglish message
- `endingMessage` → change the final message
- `--pink`, `--accent`, etc. → change colours
- `🐱`, `😽`, `🐾`, `😺` → change the cat decorations

For photos, put your images in the same folder and name them:
`photo1.jpg`, `photo2.jpg`, `photo3.jpg`, `photo4.jpg`.

You can add more photo cards by copying an `<img>` line.
